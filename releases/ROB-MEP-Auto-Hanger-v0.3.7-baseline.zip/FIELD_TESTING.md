# Revit 2025 field-test plan

The `v0.3.7-baseline` package preserves the supplied extension behavior. Offline checks are useful regressions, but they do not verify Autodesk Revit, pyRevit, fabrication content, or real model geometry. Record results in Revit **2025**, the required baseline host. Revit 2027 is mentioned by the supplied document and remains a separate unverified target.

## Preparation and evidence

Use a detached saved copy of a representative model and a small test area. Record the release ZIP checksum, Revit build, pyRevit version and engine, fabrication database/content version, selected services and hanger buttons, and link instance transform. Keep the original model and original extension installation available to compare behavior.

Extract the complete `ROBMEPHANGERS.extension` folder into a configured pyRevit extension location. The release archive may contain documentation alongside it; install the extension folder, not those documents. Reload pyRevit and confirm the HANGERS tab contains **Auto Hanger**, **Repair Draft Rods**, and **Review Extra Hangers**. Avoid two active copies of the same extension.

For each case, capture the selected duct/structure element IDs, settings, preview report, placement report, created/repaired/unchanged hanger IDs, measured rod base/top coordinates and individual lengths, and a section or 3D image. Compare preview stations to actual retained hangers after all rollbacks. Record whether each rod is natively attached or explicitly marked UNATTACHED. Report failures even when the tool gives a useful diagnostic.

The supplied README describes a prior v0.3.6 trial with 127 drafts; that count is historical context, not an expected count in a new model. Identify any existing tool-marked drafts before rerunning Auto Hanger. Repair and review them first where appropriate.

## Small-area test sequence

1. Confirm button loading, service inventory, and default Preview mode. Cancel each selection stage once to verify graceful cancellation and no model changes.
2. Run Preview on a short straight run with one service and uncomplicated native structure. Confirm Preview creates no elements or rod edits.
3. Place a small number of native hangers, inspect all rods, and rerun the same selection to check duplicate suppression.
4. Test selected IFC solids, IFC mesh geometry, transformed links, and roof fallback. Test measured unattached mode separately from native attachment.
5. Test Repair Draft Rods on one or two selected drafts before a batch. Run Review Extra Hangers and inspect flagged and known unflagged pairs.
6. Add elbow, side-tap, accessory, branch, and diffuser-drop scenarios. Evaluate actual support gaps after rejected placements.

## Scenario matrix

Each expected result below is a validation goal. A failure identifies baseline work to fix; the repository setup has not established that every goal passes.

| ID | Scenario and settings | What to inspect / expected result |
| --- | --- | --- |
| HOST-01 | Revit 2025 with the team's actual pyRevit engine and fabrication content; all three buttons. | No load/import or WPF errors. Correct service rows, selected mappings, and usable commands. |
| UI-01 | New Auto Hanger session; cancel duct, IFC, fallback, settings, and repair confirmation stages. | Preview starts enabled. Cancellation leaves the model unchanged. Inspect whether an optional roof-selection cancellation permits IFC-only operation as intended. |
| SVC-01 | Adjacent SA/RA/EA/TA or other distinct `ServiceId` runs. Include a service with no hanger palette. | Each created hanger comes from its host duct's own selected service. Missing mappings are reported and skipped. Different services remain separate in planning. |
| IFC-01 | Explicitly picked beam/joist solids directly above both rods, with a native deck also selected. | Each rod targets the selected IFC geometry first. Native attachment reports the correct link/member IDs, or the measured draft is labeled UNATTACHED. It must not be described as attached solely because its top touches the IFC. |
| IFC-02 | Two different selected framing members above the two rods, at different elevations, plus a selected higher roof. | Different member IDs and distinct individual rod lengths where geometry requires them. No copying one rod's target elevation or length to the other. |
| IFC-03 | IFC represented by tessellated meshes, including double-sided triangles, gaps between webs/flanges, and concave/hollow geometry. | Draft sizing uses the first actual mesh hit from below. A ray through a gap must not stop at a box face. Compare native fallback behavior with draft sizing; the native preferred-structure helper is solid-only in this baseline. |
| IFC-04 | Linked IFC translated, rotated about Z, and elevated; repeat with nested instance geometry and any supported nontrivial link transform. | Host XY/Z and member IDs remain correct after coordinate transforms. Check neither the link nor instance transform is omitted or applied twice. |
| IFC-05 | Selected framing with unreadable/missing bounding boxes; include one rod directly below that member and another far away. | Draft geometry attempts the unindexed member. An unrelated unreadable member does not globally block every fallback. A native roof attachment beneath an actual unindexed IFC member must be checked manually: native verification currently does not test that member. |
| IFC-06 | Automatic recognized framing versus explicit Generic Model picks; include misleading non-framing metadata and a loaded/unloaded link. | Correct link instance and intended beam/joist set. Whole-link recognition may miss insufficiently labeled Generic Models; deliberate picks can include them. Do not accept a selected nonstructural Generic Model as an approved support merely because the filter allows it. |
| ROOF-01 | One rod hits selected IFC; the other has no selected IFC hit but does hit selected native roof/deck. | Per-rod mixed IFC/roof targets, with correct individual lengths. The roof fallback must use selected geometry at each rod XY. |
| ROOF-02 | Sloped native roof/deck only; then sloped selected joists above it. | Rod lengths change across the hanger according to the actual underside/intersection. Sloped structure is distinct from sloped duct: intentionally sloped/vertical duct is currently withheld. |
| ROD-01 | No hit, below-base structure, an extremely close hit, above-limit structure, or one measurable and one unmeasurable rod. Include an IFC hit more than 0.02 ft but less than 0.10 ft above the base with an otherwise usable selected roof above it. | No guessed level, bounding-box-top target, or retained partly measurable new draft. Repair leaves an unmeasurable hanger unchanged. Capture rejection reasons and whether the valid roof is considered. The baseline currently rejects the too-close IFC case without querying roof fallback; an offline characterization test confirms that limitation. Decide and verify the intended future fallback policy before changing it. |
| ROD-02 | Multiple hanger products and their free-rod API behavior; native attached and manually sized rods. | Confirm `GetRodEndPosition()` convention, support-base stability, XY alignment, and requested versus actual length after regeneration. Refused lengths roll back. Already attached rods are not resized by Repair. |
| RUN-01 | Collinear selected connected pieces of constant size/service, with a short run, a seam at its midpoint, and a longer run. | Plan across the run rather than independently at each shop-piece end. Inspect inboard seam adjustment, safe single-midpoint support where allowed, maximum spans, and end coverage. |
| RUN-02 | Rerun RUN-01 with existing native hangers and tool-marked unattached drafts, including supports hosted on different selected pieces. | Physical duplicate insertion is reduced across the selected run. Existing drafts remain visibly unapproved; draft counting must not be interpreted as approved anchorage. Existing hangers are not automatically moved or deleted. |
| RUN-03 | Same-service ducts close at endpoints but not connected; parallel nearby runs; real connection with a size/service change or elbow. | Detect false geometric grouping or missed desired continuity. The current grouping uses endpoint tolerances rather than a full connector graph. Inspect both proposal count and actual host choice. |
| SPAN-01 | Rectangular widths/heights around half-perimeter thresholds 72 and 120 in; round diameters around 24, 36, 60, and 96 in; oval. Repeat with overall caps 4 and 8 ft. Inspect any invalid or unreadable profile dimensions without changing valid model content to manufacture them. | Verify preliminary schedule boundaries and the smaller overall cap. Confirm dimensions are in feet internally and user entries use stated units. The offline spacing rule currently accepts some invalid rectangular dimensions, such as negative width with a positive summed half-perimeter; a characterization test preserves that known limitation. Future validation should reject invalid individual dimensions. |
| SPAN-02 | Half Strap and Trapeze choices, optional rectangular width threshold, insulation/loading, and the approved support schedule. | Verify selected product and threshold mapping. This baseline does not derive spacing from support hardware or loads; record any required manual reductions and future schedule inputs. Do not treat current caps as certified SMACNA maxima. |
| CLASH-01 | Side tap, tee/branch, inline damper/accessory, adjacent duct/pipe, and an obstacle at a planned support station. | Stations move to legal clearance intervals or the run is withheld/reported partial. A relocation must retain actual maximum span, end/branch coverage, and correct hanger alignment. |
| CLASH-02 | Nearby native duct, pipe, accessories, mechanical equipment, and a rod-only overhead obstruction; repeat with linked MEP and irregular geometry. | Native envelope conflicts reject and roll back candidates when checks are enabled. Separate false positives from actual rod/hardware contact. Linked MEP and exact solid clashes require manual review in this baseline. |
| TURN-01 | Real elbows/change of direction at one and both ends; short pieces with no legal station. Compare experimental fitting-extension option off/on. | Keep near-turn support checks. Fitting probes only survive valid host/rod checks; Preview does not prove a legal throat. Record any missing support after a probe fails. |
| DROP-01 | Connected horizontal duct to downturned elbow to air terminal; disconnected diffuser family; vertical drop and intervening accessories. | Horizontal support remains near the turn where possible. No hanger is placed on the vertical drop or diffuser by this path. Review independent diffuser/drop support and connector-heuristic warnings. |
| DRAFT-01 | Enable retained UNATTACHED mode under measurable IFC/roof when native attachment cannot be accepted. Then disable it and repeat. | Kept drafts are aligned to host duct, individually geometry-sized, and marked in Comments with target information. The disabled mode retains no such draft. The baseline requires measured structure, not arbitrary unmeasured rod heights. |
| DRAFT-02 | Manually Attach to Structure after DRAFT-01 using recognized native host(s). | Confirm rods/anchors attach as intended and inspect lengths afterward. Subsequent Repair must not resize attached rods. Review the historical draft marker when classifying attachment status. |
| REPAIR-01 | Selected drafts and then a mixed batch containing valid, unmeasurable, attached, and read-only-comment examples. | Only accepted unattached drafts update in place; no creation/deletion or claimed automatic attachment. Failed per-hanger edits roll back. Verify rod-path clashes manually because Repair does not run Auto Hanger's clearance scan. |
| EXTRA-01 | Same-service parallel draft pairs at 6, 11, 12, and 13 in; different services, crossing axes, close supports on distinct runs, negative coordinates, and pairs spanning two 0.75-ft bucket indices. | Reports and optional selection create/delete nothing. Inspect threshold/bucket misses and false positives. Same-service parallel hosts within 1 ft do not alone establish redundant support. |
| TX-01 | API failure/refused rod length/invalid creation midway through a small batch. | Failed candidates roll back cleanly; retained IDs match reports; final gaps and remaining partial work are visible. Preserve a minimal model reproducer. |

## Result record

Copy the following into a field report for each scenario:

```text
Scenario ID:
Release ZIP and SHA256:
Revit 2025 build / pyRevit version / engine:
Fabrication content and service IDs:
Duct IDs / structure IDs / link instance and transform:
Settings and selected hanger buttons:
Preview proposed count and reported issues:
Actual retained native / draft / failed count and hanger IDs:
Per-rod base XY/Z, target XY/Z, target member ID, actual length:
Measured spans, end/branch distances, and hardware clearance:
Expected result / observed result / pass or fail:
Screenshots, output log, and minimal detached reproducer:
```

Proceed to larger selections only after the small-area host, targeting, rod, and rollback cases are understood. The field report should distinguish geometric contact, native attachment, physical duplicate suppression, and project-approved support adequacy.
