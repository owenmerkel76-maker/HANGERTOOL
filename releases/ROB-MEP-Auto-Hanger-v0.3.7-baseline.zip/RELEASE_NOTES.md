# ROB MEP Auto Hanger v0.3.7 — IFC Picker Upgrade

This complete package replaces the previous preserved-baseline download.
Install the entire `ROBMEPHANGERS.extension` directory in the configured pyRevit
extension search path and reload pyRevit. Replace the previous installation
rather than loading two active copies. All three buttons are included.

Auto Hanger now provides a Structural Target Selection window with multiple
model, category and type checkboxes, preferred/fallback roles, element counts,
IFC classifications, structural profile hints and direct member selection.
Generic Models and proxies require review and explicit approval. Confirmed
preferences are remembered per project and checked against current sources.

Individual rods use actual transformed Solid/Mesh intersections. Approved
fallback can be used when the preferred rod path is obstructed. Unreadable
geometry and rods starting inside closed steel meshes are rejected. Existing
duct spacing/planning, service mappings, preview, unattached draft placement
and rollback safeguards are retained. Shared geometry helpers in Repair Draft
Rods are synchronized; Review Extra Hangers remains unchanged.

245 offline tests passed before packaging. Revit 2025 WPF interaction, real IFC
geometry, fabrication rod APIs, native attachment and actual model transactions
remain field-test requirements. Structural models nested inside another linked
model must currently be linked directly into the host. MEP envelopes remain
conservative screening, not exact hanger-hardware clearance certification.

Read `IFC_STRUCTURE_SELECTION.md` and `FIELD_TESTING.md` before using a detached
test model. `README_FIRST.md` is the preserved original v0.3.7 documentation;
its older structural-selection instructions are superseded by these notes and
the picker guide. The historical download filename is retained so existing
GitHub links retrieve this updated package.
