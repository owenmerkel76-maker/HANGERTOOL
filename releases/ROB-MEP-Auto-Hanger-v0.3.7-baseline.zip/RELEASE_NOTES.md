# ROB MEP Auto Hanger v0.3.7 — IFC Picker Upgrade

## Focused selection and field-result correction

Choose the IFC structural link(s) before loading type information. Only those
links are inventoried; the default host contribution is native roof/deck and
reviewable imported IFC. The support window normally shows only **Beams /
joists** and **Roof / deck fallback**. Categories, classifications and sample
names are available in tooltips. Custom/unclassified IFC types remain behind
an explicit manual-review checkbox; bulk model/section selection cannot approve
them. Duct selection and hanger mappings remain in the existing service workflow.

Type metadata is reused per type. Instance descriptions no longer produce a
separate type row for every beam. Offline regression with 250 same-type members
checks one type lookup and one grouped row. This is operation-count evidence,
not a measured Revit speedup.

Your field report showed 123 planned stations, 122 rejected draft attempts and
zero retained hangers. The same first five unreadable host objects repeatedly
blocked measurement. Broad host/custom approvals are now excluded by default;
unlocatable/unreadable approved objects are reported once before placement.
Readable primitive extents can index unboxed members for broad-phase screening,
but rod elevations still require actual intersections. Unrelated native Generic
Model helpers and view-only annotations are not global rod-obstruction vetoes;
approved objects and identified IFC structure still receive fail-closed checks.

261 offline tests pass. Retest a small detached area with the actual IFC link
and optional native deck, then inspect both rod targets and lengths before a
large run. The field model is unavailable here; successful placement and actual
menu timings still need your Revit test.

This complete package replaces the previous preserved-baseline download.
Install the entire `ROBMEPHANGERS.extension` directory in the configured pyRevit
extension search path and reload pyRevit. Replace the previous installation
rather than loading two active copies. All three buttons are included.

Auto Hanger now provides a Structural Target Selection window with multiple
model, category and type checkboxes, preferred/fallback roles, element counts,
IFC classifications, structural profile hints and direct member selection.
Generic Models and proxies require review and explicit approval. Confirmed
preferences are remembered per project and checked against current sources.

Individual rods use actual transformed Solid/Mesh intersections. Approved
fallback can be used when the preferred rod path is obstructed. Unreadable
geometry and rods starting inside closed steel meshes are rejected. Existing
duct spacing/planning, service mappings, preview, unattached draft placement
and rollback safeguards are retained. Shared geometry helpers in Repair Draft
Rods are synchronized; Review Extra Hangers remains unchanged.

261 offline tests passed before packaging. Revit 2025 WPF interaction, real IFC
geometry, fabrication rod APIs, native attachment and actual model transactions
remain field-test requirements. Structural models nested inside another linked
model must currently be linked directly into the host. MEP envelopes remain
conservative screening, not exact hanger-hardware clearance certification.

Read `IFC_STRUCTURE_SELECTION.md` and `FIELD_TESTING.md` before using a detached
test model. `README_FIRST.md` is the preserved original v0.3.7 documentation;
its older structural-selection instructions are superseded by these notes and
the picker guide. The historical download filename is retained so existing
GitHub links retrieve this updated package.


### Field targeting diagnostics and discovery progress

The next field run followed preferred-only targeting: 579 preferred members,
48 planned stations, 47 rejected attempts and no retained hangers. Every attempt
reported no measurable target at rod 0. The 146 fallback members were inventory
counts, not evidence of active fallback targeting. These results do not identify
a transform, geometry, maximum-length or physical alignment defect by themselves.

Target misses now report host and source-local rod base coordinates in feet,
active priority, rod limit, selected count, transformed XY overlap, below-base
and beyond-limit screening, actual intersection tests, misses, unreadable
geometry and hits. Bounds remain screening only; lengths require actual hits.
This diagnostic update does not invent targets or retain unmeasured drafts.
The per-source counters describe each lookup, not unique objects across a run.

Discovery now reads classifier/profile parameters in one pass instead of
repeated named searches, retaining exporter-specific fields. The menu transition
has a per-model progress indicator. Real Revit discovery timing is unmeasured.

265 offline tests passed; original archive verification passed. Field testing
is still required for actual Revit geometry, rod endpoint conventions, link
transforms and UI performance. Test a small detached-model area first and return
the new diagnostics, a section view through one failed station and the chosen
maximum rod length. This package does not claim successful field placement.
