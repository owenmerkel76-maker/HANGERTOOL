# -*- coding: utf-8 -*-
"""Per-run linked rod clearance checks; no planner or attachment decisions.

MEP boxes are conservative *potential* clashes. Other imported/structural
geometry is rejected only on an actual Solid/Mesh path intersection, or on an
unreadable local candidate that cannot establish clearance. All feet and
coordinates supplied to ``check`` are in the host document. Autodesk imports
are lazy so this deployed helper can also be exercised with offline doubles.
"""

import math
import re


try:
    text_type = unicode
except NameError:
    text_type = str


def _text(value):
    """Keep Revit/.NET and IFC labels Unicode under IronPython 2."""
    try:
        return text_type(value)
    except UnicodeError:
        try:
            return value.decode('utf-8', 'replace')
        except Exception:
            return u'(unreadable text)'


_MEP_CATEGORIES = (
    'OST_FabricationDuctwork', 'OST_FabricationPipework',
    'OST_DuctCurves', 'OST_PipeCurves', 'OST_FlexDuctCurves',
    'OST_FlexPipeCurves', 'OST_DuctFitting', 'OST_PipeFitting',
    'OST_DuctAccessory', 'OST_PipeAccessory', 'OST_MechanicalEquipment',
    'OST_DuctTerminal', 'OST_PlumbingFixtures', 'OST_Sprinklers',
    'OST_CableTray', 'OST_CableTrayFitting', 'OST_Conduit', 'OST_ConduitFitting')
_GEOMETRY_CATEGORIES = (
    'OST_StructuralFraming', 'OST_StructuralColumns', 'OST_Columns',
    'OST_Floors', 'OST_Roofs', 'OST_StructuralFoundation', 'OST_Walls',
    'OST_Ceilings', 'OST_Stairs', 'OST_GenericModel')
_METADATA_PARAMETERS = (
    'IfcEntity', 'IfcExportAs', 'IfcType', 'IfcName', 'IFC Export As',
    'IFC Class', 'IFC Entity', 'IFC Type', 'IFC Classification',
    'IfcObjectType', 'ObjectType', 'Description', 'Type Comments')
_MEP_IFC = ('ifcflowsegment', 'ifcflowfitting', 'ifcflowcontroller',
            'ifcflowterminal', 'ifcflowmovingdevice', 'ifcflowstoragedevice',
            'ifcflowtreatmentdevice', 'ifcenergyconversiondevice',
            'ifcdistributionelement', 'ifcductsegment', 'ifcpipesegment',
            'ifcductfitting', 'ifcpipefitting')
_GEOMETRY_IFC = ('ifcbeam', 'ifcmember', 'ifccolumn', 'ifcslab',
                 'ifcroof', 'ifcplate', 'ifcwall', 'ifcfooting',
                 'ifcbuildingelementproxy', 'ifcproxy', 'ifcstair', 'ifcramp')
_MEP_WORDS = re.compile(r'\b(duct(?:work)?|pipe(?:work)?|piping|diffuser|'
                        r'sprinkler|air\s+terminal|mechanical\s+equipment|'
                        r'air\s+handling|ahu|vav|fan\s+coil|conduit|cable\s+tray)\b',
                        re.I)


def _eid(value):
    try:
        return int(value.Value)
    except Exception:
        try:
            return int(value.IntegerValue)
        except Exception:
            return int(value)


def _point(value):
    try:
        result = (float(value.X), float(value.Y), float(value.Z))
    except AttributeError:
        result = tuple(float(value[i]) for i in range(3))
    if any(math.isnan(v) or math.isinf(v) for v in result):
        raise ValueError('non-finite rod coordinates')
    return result


def _xyz(value):
    from Autodesk.Revit.DB import XYZ
    return XYZ(*_point(value))


def _box_overlap(a, b, padding=0.):
    return all(a[i] <= b[i + 3] + padding and b[i] <= a[i + 3] + padding
               for i in range(3))


def _path_box(a, b, padding=0.):
    return tuple(min(a[i], b[i]) - padding for i in range(3)) + tuple(
        max(a[i], b[i]) + padding for i in range(3))


def _inset(a, b, distance, from_end=False):
    delta = tuple(b[i] - a[i] for i in range(3))
    length = math.sqrt(sum(v * v for v in delta))
    fraction = min(distance / length, .1) if length else 0.
    if from_end:
        return tuple(b[i] - delta[i] * fraction for i in range(3))
    return tuple(a[i] + delta[i] * fraction for i in range(3))


def world_bbox(element, link_transform):
    """All eight corners: element bbox transform, then link-to-host transform."""
    try:
        box = element.get_BoundingBox(None)
        if box is None:
            return None
        points = []
        for x in (box.Min.X, box.Max.X):
            for y in (box.Min.Y, box.Max.Y):
                for z in (box.Min.Z, box.Max.Z):
                    point = _xyz((x, y, z))
                    point = box.Transform.OfPoint(point)
                    if link_transform is not None:
                        point = link_transform.OfPoint(point)
                    points.append(_point(point))
        if not points:
            return None
        return tuple(min(p[i] for p in points) for i in range(3)) + tuple(
            max(p[i] for p in points) for i in range(3))
    except Exception:
        return None


def _category_sets():
    from Autodesk.Revit.DB import BuiltInCategory, ElementId
    result = []
    for names in (_MEP_CATEGORIES, _GEOMETRY_CATEGORIES):
        numbers = set()
        for name in names:
            try:
                numbers.add(_eid(ElementId(getattr(BuiltInCategory, name))))
            except Exception:
                pass
        result.append(numbers)
    return result


def _category(element):
    try:
        return _eid(element.Category.Id), _text(element.Category.Name)
    except Exception:
        return None, '(uncategorized)'


def _metadata_text(element, document):
    """Read classification/name metadata, including type-level IFC properties."""
    objects = [element]
    try:
        typ = document.GetElement(element.GetTypeId())
        if typ is not None:
            objects.append(typ)
    except Exception:
        pass
    parts = []
    for obj in objects:
        for name in ('Name', 'FamilyName'):
            try:
                value = getattr(obj, name)
                if value:
                    parts.append(_text(value))
            except Exception:
                pass
        for name in _METADATA_PARAMETERS:
            try:
                param = obj.LookupParameter(name)
                if param is not None:
                    value = param.AsString() or param.AsValueString()
                    if value:
                        parts.append(_text(value))
            except Exception:
                pass
        # Exporters also prefix or rename IFC class parameters. Do not rely
        # solely on one localized parameter spelling.
        try:
            for param in obj.Parameters:
                if 'ifc' in _text(param.Definition.Name).lower():
                    value = param.AsString() or param.AsValueString()
                    if value:
                        parts.append(_text(value))
        except Exception:
            pass
    return u' '.join(parts).lower()


def obstacle_kind(category_id, metadata, mep_categories, geometry_categories):
    """Generic models are geometry candidates, never automatically known MEP."""
    text = _text(metadata or u'').lower()
    if category_id in mep_categories or any(name in text for name in _MEP_IFC):
        return 'mep'
    is_proxy = 'ifcbuildingelementproxy' in text or 'ifcproxy' in text
    if is_proxy and _MEP_WORDS.search(text):
        return 'mep'
    if category_id in geometry_categories or any(name in text for name in _GEOMETRY_IFC):
        return 'geometry'
    return None


def _loaded_links(document):
    from Autodesk.Revit.DB import FilteredElementCollector, RevitLinkInstance
    return FilteredElementCollector(document).OfClass(RevitLinkInstance)


def _linked_elements(document):
    from Autodesk.Revit.DB import FilteredElementCollector
    return FilteredElementCollector(document).WhereElementIsNotElementType()


def _is_import_geometry(element):
    try:
        name = _text(element.GetType().Name)
    except Exception:
        name = type(element).__name__
    return name in ('DirectShape', 'ImportInstance')


def _intersection(element, start, end, transform, host_base):
    import rod_geometry
    return rod_geometry._intersection_result(element, start, end, transform, host_base)


def _matches_endpoint(target, candidate, path_index, tip):
    """Exact element AND link instance; a same-ID member in another link stays."""
    if target.get('index') != path_index:
        return False
    try:
        if _eid(target.get('id')) != candidate['id']:
            return False
        if candidate['link_id'] is None:
            # An explicit native identity is required; absent link information
            # must not accidentally exempt a same-ID host element.
            if target.get('link_id') is not None:
                return False
            if not ('link_id' in target or target.get('source_key') == 'HOST'):
                return False
        elif target.get('link_id') is not None:
            if _eid(target['link_id']) != candidate['link_id']:
                return False
        elif target.get('source_key'):
            if _text(target['source_key']) != candidate['source_key']:
                return False
        else:
            return False
        return abs(float(target['z']) - tip[2]) <= .01
    except Exception:
        return False


class LinkedObstructionChecker(object):
    """Cache one immutable obstacle inventory for one Auto Hanger run only.

    An unloaded link is recorded in ``warnings``; its absent geometry is never
    advertised as evaluated. The structural picker handles missing approved
    structure. Loaded unreadable sources instead reject checks explicitly.
    """

    def __init__(self, doc):
        self.doc = doc
        self.candidates = None
        self.warnings = []
        self.failures = []

    def prepare(self):
        """Read the inventory before placement so warnings/failures are visible.

        Safe to repeat: preparation only reads documents and caches this run's
        candidates. ``check`` still prepares lazily for standalone callers.
        """
        self._gather()
        return self

    def _gather(self):
        if self.candidates is not None:
            return
        self.candidates = []
        try:
            mep_categories, geometry_categories = _category_sets()
            links = list(_loaded_links(self.doc))
        except Exception as ex:
            self.failures.append(u'Linked rod clearance inventory unavailable: {}'.format(_text(ex)))
            return
        # Native structural objects can also obstruct a rod that is targeted
        # to a higher linked beam. Existing native MEP checks are retained by
        # the caller; only non-MEP native categories/imported IFC objects are
        # added here, using the same exact geometric clearance test.
        try:
            self._gather_document(self.doc, None, 'HOST', 'host model', None,
                                  None, mep_categories, geometry_categories,
                                  native=True)
        except Exception as ex:
            self.failures.append(u'Native structural rod clearance inventory unavailable: {}'.format(_text(ex)))
        for link in links:
            try:
                link_id = _eid(link.Id)
                link_name = _text(link.Name)
            except Exception:
                link_id, link_name = None, '(unnamed linked model)'
            try:
                document = link.GetLinkDocument()
                if document is None:
                    self.warnings.append(u'Linked model {} is unloaded; its clearance geometry was not checked'.format(link_name))
                    continue
                transform = link.GetTotalTransform()
                inverse = transform.Inverse
                source_key = _text(getattr(link, 'UniqueId', '') or link_id)
                self._gather_document(document, link_id, source_key, link_name,
                    transform, inverse, mep_categories, geometry_categories)
            except Exception as ex:
                self.failures.append(u'Linked rod clearance inventory unavailable for {}: {}'.format(link_name, _text(ex)))

    def _gather_document(self, document, link_id, source_key, name, transform,
                         inverse, mep_categories, geometry_categories, native=False):
        for element in _linked_elements(document):
            category_id, category_name = _category(element)
            if native and category_id in mep_categories:
                continue
            kind = obstacle_kind(category_id, _metadata_text(element, document),
                                 mep_categories, geometry_categories)
            if kind is None and _is_import_geometry(element):
                kind = 'geometry'
            if kind is None:
                continue
            self.candidates.append({
                'element': element, 'id': _eid(element.Id), 'link_id': link_id,
                'source_key': source_key, 'link_name': name,
                'category': category_name, 'kind': kind, 'transform': transform,
                'inverse': inverse, 'box': world_bbox(element, transform)})

    def check(self, paths, approved_targets=None, host_id=None):
        """Return diagnostics; empty list means loaded inventory passed checks.

        ``paths`` contains {index, base, tip}, each point XYZ or 3-tuple in host
        coordinates. An approved target exempts only its precise endpoint,
        never the member's body or a different link with the same ElementId.
        """
        self._gather()
        diagnostics = list(self.failures)
        targets = approved_targets or []
        for path in paths:
            index = path.get('index', '?')
            try:
                base, tip = _point(path['base']), _point(path['tip'])
                if tip[2] <= base[2] or math.sqrt(sum((tip[i] - base[i]) ** 2 for i in range(3))) < .02:
                    raise ValueError('rod path is not a valid upward segment')
                start = _inset(base, tip, .01)
            except Exception as ex:
                diagnostics.append(u'Rod {} linked clearance path unavailable: {}'.format(index, _text(ex)))
                continue
            for candidate in self.candidates:
                if candidate['link_id'] is None and host_id is not None and candidate['id'] == _eid(host_id):
                    continue
                scope = 'native' if candidate['link_id'] is None else 'linked'
                name = u'{} / {} element {}'.format(candidate['link_name'],
                                                    candidate['category'], candidate['id'])
                if candidate['kind'] == 'mep' and candidate['box'] is not None:
                    if _box_overlap(_path_box(start, tip, .10), candidate['box']):
                        diagnostics.append(u'Rod {} potential {} MEP clash with {} (bounding-box screening; verify in 3D)'.format(index, scope, name))
                    continue
                end = tip
                if any(_matches_endpoint(row, candidate, index, tip) for row in targets):
                    end = _inset(start, tip, .005, from_end=True)
                if candidate['box'] is not None and not _box_overlap(_path_box(start, end), candidate['box'], .001):
                    continue
                try:
                    local_start, local_end = _xyz(start), _xyz(end)
                    if candidate['inverse'] is not None:
                        local_start = candidate['inverse'].OfPoint(local_start)
                        local_end = candidate['inverse'].OfPoint(local_end)
                    state, height = _intersection(candidate['element'], local_start,
                        local_end, candidate['transform'], start[2])
                except Exception:
                    state, height = 'unknown', None
                if state == 'hit':
                    diagnostics.append(u'Rod {} intersects {} obstructing geometry {} (actual Solid/Mesh path intersection)'.format(index, scope, name))
                elif state != 'miss':
                    location = 'intersecting bounding box' if candidate['box'] is not None else 'no readable bounding box'
                    diagnostics.append(u'Rod {} potential {} blockage at {} ({}; geometry unavailable, clearance unverified)'.format(index, scope, name, location))
        return diagnostics


def check_linked_paths(doc, paths, approved_targets=None, host_id=None):
    """Convenience API; use ``LinkedObstructionChecker`` to cache a whole run.

    ``host_id`` belongs to the HOST document, so it cannot exempt linked
    elements merely because their independent document IDs happen to match.
    """
    return LinkedObstructionChecker(doc).check(paths, approved_targets, host_id)
