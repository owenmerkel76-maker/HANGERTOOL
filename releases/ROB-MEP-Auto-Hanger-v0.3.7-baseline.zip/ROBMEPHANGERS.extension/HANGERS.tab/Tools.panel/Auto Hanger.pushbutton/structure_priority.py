# -*- coding: utf-8 -*-
"""ROB MEP Auto Hanger v0.3.5 -- linked IFC preference and native fallback.

Reference selection uses Revit's ObjectType.LinkedElement and reads
Reference.LinkedElementId. Native fabrication rods must report the actual
LinkElementId to be counted as attached. Never equate geometric proximity
or manual rod length to a verified structural attachment.
"""
import math
from Autodesk.Revit.DB import (BuiltInCategory, FilteredElementCollector,
                               RevitLinkInstance, XYZ, Options, Solid,
                               GeometryInstance, Line, SolidCurveIntersectionOptions)
from Autodesk.Revit.UI.Selection import ISelectionFilter, ObjectType
from Autodesk.Revit.Exceptions import OperationCanceledException
from pyrevit import forms


def eidnum(eid):
    try:
        return int(eid.Value)
    except Exception:
        return int(eid.IntegerValue)


def catnum(el):
    try:
        return eidnum(el.Category.Id)
    except Exception:
        return None


def nums(*bics):
    from Autodesk.Revit.DB import ElementId
    return set(eidnum(ElementId(b)) for b in bics)

# IFC beams and joists are frequently converted to DirectShape/Generic Models.
# Generic Models are accepted on deliberate member picks. An entire link
# includes Generic Models only when their IFC metadata identifies framing.
FRAMING_CATS = nums(BuiltInCategory.OST_StructuralFraming,
                    BuiltInCategory.OST_StructuralColumns,
                    BuiltInCategory.OST_Columns)
GENERIC_CATS = nums(BuiltInCategory.OST_GenericModel)
FRAME_WORDS = ('ifcbeam','ifccolumn','ifcmember',
               'beam','joist','girder','truss','purlin','rafter','column',
               'steel frame','steel framing','wide flange','channel')


def name_for(el):
    parts=[]
    for name in ('Name','FamilyName'):
        try:
            val=getattr(el,name)
            if val: parts.append(str(val))
        except Exception:
            pass
    for name in ('IfcEntity','IfcExportAs','IfcType','IfcName','IFC Export As',
                 'IFC Class','IFC Entity','Description'):
        try:
            p=el.LookupParameter(name)
            if p:
                val=p.AsString() or p.AsValueString()
                if val: parts.append(str(val))
        except Exception:
            pass
    return ' '.join(parts).lower()


def candidate_link_part(el, explicit=False):
    c=catnum(el)
    if c in FRAMING_CATS:
        return True
    if c in GENERIC_CATS:
        return bool(explicit or any(t in name_for(el) for t in FRAME_WORDS))
    return False


class LinkedFrameFilter(ISelectionFilter):
    def __init__(self, link):
        self.link=link
        self.doc=link.GetLinkDocument()
        self.link_id=eidnum(link.Id)

    def AllowElement(self, el):
        return isinstance(el,RevitLinkInstance) and eidnum(el.Id)==self.link_id

    def AllowReference(self, ref, position):
        try:
            if eidnum(ref.ElementId)!=self.link_id:
                return False
            candidate=self.doc.GetElement(ref.LinkedElementId)
            return candidate is not None and candidate_link_part(candidate,True)
        except Exception:
            return False


def readable_link(link):
    try:
        doc=link.GetLinkDocument()
        name=doc.Title if doc else '(UNLOADED)'
    except Exception:
        name='(UNLOADED)'
    return '{} | instance #{}'.format(name,eidnum(link.Id))


def choose_link(doc):
    links=[x for x in FilteredElementCollector(doc).OfClass(RevitLinkInstance)
           if x.GetLinkDocument() is not None]
    if not links:
        forms.alert('No loaded Revit/IFC link was found. Link the IFC into Revit '
                    'first, or run again using native structure only.')
        return None
    choices={readable_link(x):x for x in links}
    names=sorted(choices)
    chosen=forms.SelectFromList.show(names,title='AUTO HANGER - choose linked IFC framing',
                                     button_name='Use selected link',multiselect=False)
    return choices.get(chosen)


def select_linked_members(uidoc,link):
    mode=forms.CommandSwitchWindow.show(
        ['Use all recognized framing in this IFC link',
         'Pick specific beams / joists from this IFC link'],
        message='Preferred structure selection (linked IFC)')
    if not mode:
        return None
    link_doc=link.GetLinkDocument()
    if link_doc is None:
        forms.alert('The chosen link is not loaded.')
        return None
    if mode.startswith('Use all'):
        chosen={}
        n=0
        for el in FilteredElementCollector(link_doc).WhereElementIsNotElementType():
            n+=1
            if n>70000:
                forms.alert('Linked IFC contains more than 70,000 elements. '
                            'Use Pick specific beams/joists for performance.')
                return None
            if candidate_link_part(el,False):
                chosen[eidnum(el.Id)]=el
                if len(chosen)>20000:
                    forms.alert('More than 20,000 recognized framing members in the IFC. '
                                'Pick only the framing members needed for your duct area.')
                    return None
    else:
        refs=uidoc.Selection.PickObjects(ObjectType.LinkedElement,LinkedFrameFilter(link),
                     'AUTO HANGER: select IFC beam/joist MEMBERS, then Finish')
        chosen={}
        for r in refs:
            if eidnum(r.ElementId)!=eidnum(link.Id):
                continue
            el=link_doc.GetElement(r.LinkedElementId)
            if el is not None and candidate_link_part(el,True):
                chosen[eidnum(el.Id)]=el
    if not chosen:
        forms.alert('No usable linked framing members were selected/detected. '
                    'For IFC objects listed as Generic Models, use Pick specific '
                    'beams/joists and click the members directly.')
        return None
    return chosen


def box_world(bbox,trans):
    """Bounding box extents in host coordinates, including transform of link."""
    # Revit element BoundingBox's local Transform may be non-identity.
    btrans=bbox.Transform
    pts=[]
    for x in (bbox.Min.X,bbox.Max.X):
        for y in (bbox.Min.Y,bbox.Max.Y):
            for z in (bbox.Min.Z,bbox.Max.Z):
                p=btrans.OfPoint(XYZ(x,y,z))
                pts.append(trans.OfPoint(p))
    return (min(p.X for p in pts),max(p.X for p in pts),
            min(p.Y for p in pts),max(p.Y for p in pts),
            min(p.Z for p in pts),max(p.Z for p in pts))


def each_solid(geometry,depth=0):
    if geometry is None or depth>5:
        return
    for obj in geometry:
        if isinstance(obj,Solid):
            try:
                if obj.Volume>1e-9:
                    yield obj
            except Exception:
                pass
        elif isinstance(obj,GeometryInstance):
            try:
                for s in each_solid(obj.GetInstanceGeometry(),depth+1):
                    yield s
            except Exception:
                pass


def intersect_vertical_solid(element,local_start,local_end):
    """True on solid hit; None if geometry was uncheckable (fail closed)."""
    opts=Options()
    opts.IncludeNonVisibleObjects=False
    opts.ComputeReferences=False
    try:
        geometry=element.get_Geometry(opts)
    except Exception:
        return None
    if geometry is None:
        return None
    try:
        line=Line.CreateBound(local_start,local_end)
    except Exception:
        return None
    solids=0
    failures=0
    intersects=SolidCurveIntersectionOptions()
    try:
        for solid in each_solid(geometry):
            solids+=1
            try:
                segments=solid.IntersectWithCurve(line,intersects)
                if segments is not None and segments.SegmentCount>0:
                    return True
            except Exception:
                failures+=1
    finally:
        try: intersects.Dispose()
        except Exception: pass
    if not solids or failures:
        return None
    return False


class StructureChoice(object):
    def __init__(self,link=None,preferred=None,fallback=None):
        self.link=link
        self.preferred=preferred or {}
        self.fallback=set(fallback or [])
        self.link_id=eidnum(link.Id) if link is not None else None
        self.transform=link.GetTotalTransform() if link is not None else None
        self.inverse=self.transform.Inverse if self.transform is not None else None
        self.bounds=[]
        self.bad_boxes=0
        self.indexed_ids=set()
        if self.link is not None:
            for member_id,el in self.preferred.items():
                try:
                    bb=el.get_BoundingBox(None)
                    if bb is None:
                        self.bad_boxes+=1
                    else:
                        self.bounds.append((member_id,el,box_world(bb,self.transform)))
                        self.indexed_ids.add(member_id)
                except Exception:
                    self.bad_boxes+=1

    def over_preferred(self,origin,max_length):
        """Return ('yes'/'no'/'unknown', id) for solid above rod location."""
        if self.link is None:
            return 'no',None
        tolerance=.10
        # v0.3.6 regression: one unreadable IFC element bounding box
        # globally blocked EVERY native roof fallback. Do not treat an
        # unlocated element as a confirmed obstacle to every hanger. Local
        # candidate intersections remain fail-closed below.
        uncertain=False
        suspects=[]
        for member_id,el,bounds in self.bounds:
            x1,x2,y1,y2,z1,z2=bounds
            if (x1-tolerance<=origin.X<=x2+tolerance and
                y1-tolerance<=origin.Y<=y2+tolerance and
                z2>=origin.Z-.1 and z1<=origin.Z+max_length+.1):
                suspects.append((member_id,el))
        if not suspects and not uncertain:
            return 'no',None
        if len(suspects)>70:
            return 'unknown',None
        lower=self.inverse.OfPoint(origin)
        upper=self.inverse.OfPoint(XYZ(origin.X,origin.Y,origin.Z+max_length))
        for member_id,el in suspects:
            hit=intersect_vertical_solid(el,lower,upper)
            if hit is True:
                return 'yes',member_id
            if hit is None:
                uncertain=True
        if uncertain:
            return 'unknown',None
        return 'no',None

    def verify(self,hanger,max_rod_ft):
        """Verify actual Revit-native LinkElementId for *every* rod."""
        info=None
        try:
            info=hanger.GetRodInfo()
            if info is None or info.RodCount<1 or not info.IsAttachedToStructure:
                return False,'No native structural rod attachment',None
            levels=[]
            for i in range(info.RodCount):
                length=float(info.GetRodLength(i))
                if length<=0 or length>max_rod_ft:
                    return False,'Rod {} length {:.2f} ft outside 0-{:.1f} ft'.format(i,length,max_rod_ft),None
                attached=info.GetRodAttachedElementId(i)
                if attached is None:
                    return False,'Rod {} did not report a structural attachment'.format(i),None
                linknum=eidnum(attached.LinkInstanceId)
                if self.link_id is not None and linknum==self.link_id:
                    member=eidnum(attached.LinkedElementId)
                    if member not in self.preferred:
                        return False,'Rod {} linked to unselected IFC member {}'.format(i,member),None
                    levels.append('IFC')
                    continue
                native=eidnum(attached.HostElementId)
                if native not in self.fallback:
                    return False,'Rod {} attached to unselected structure {}'.format(i,native),None
                if self.link is not None:
                    # Rod-end position is the top end. Its Z minus actual
                    # length approximates rod base. For user-controlled IFC
                    # precedence require geometry testing above that base.
                    top=info.GetRodEndPosition(i)
                    base=XYZ(top.X,top.Y,top.Z-length)
                    hits,frame_id=self.over_preferred(base,max_rod_ft)
                    if hits=='yes':
                        return False,('Rod {} hit roof deck while IFC member {} is above it; '
                                      'Revit auto-attachment cannot choose a specified target'
                                      .format(i,frame_id)),None
                    if hits=='unknown':
                        return False,('Rod {} roof fallback held: IFC geometry not reliably '
                                      'verifiable at this position'.format(i)),None
                levels.append('ROOF')
            return True,'Verified {} rods against selected IFC/roof structure'.format(info.RodCount),'+'.join(sorted(set(levels)))
        except Exception as ex:
            return False,'Rod attachment verification failed: {}'.format(ex),None
        finally:
            if info:
                try: info.Dispose()
                except Exception: pass
